#include <stdarg.h> 	// for variadic function
#include <stdlib.h>
#ifndef HELPER_H
#define HELPER_H

int compareArrays(u_int8_t a[], u_int8_t b[], int n);
void printPayload(unsigned char *data,unsigned int size;
//unsigned char* concat(unsigned char *dest , int size, int count, ...);


#endif